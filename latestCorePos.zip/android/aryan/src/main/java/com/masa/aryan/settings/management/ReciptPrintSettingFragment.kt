package com.masa.aryan.settings.management

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.masa.aryan.base.BaseFragment
import com.masa.aryan.buy.viewmodel.BuySuccessViewModel
import com.masa.aryan.databinding.FragmentReciptPrintSettingBinding
import com.masa.aryan.main.view.LoadingFragment
import com.masa.aryan.settings.management.viewmodel.ReciptPrintSettingViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ReciptPrintSettingFragment : BaseFragment<FragmentReciptPrintSettingBinding>() {

 @Inject
 lateinit var loading: LoadingFragment

 @Inject
 lateinit var appContext: Context

 @Inject
 lateinit var sharedpref : SharedPreferences



 private val viewModel: ReciptPrintSettingViewModel by viewModels()


 override fun getViewBinding(
  inflater: LayoutInflater,
  container: ViewGroup?
 ) = FragmentReciptPrintSettingBinding.inflate(inflater, container, false)

 override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
  super.onViewCreated(view, savedInstanceState)
//  binding.viewModel = viewModel



   binding.back.setOnClickListener {
    finish(this)
   }

   onBackPressed.observe(viewLifecycleOwner) {
    finish(this)
   }
  }
 }




