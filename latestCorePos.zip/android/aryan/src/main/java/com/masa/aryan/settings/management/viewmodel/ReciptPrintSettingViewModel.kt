package com.masa.aryan.settings.management.viewmodel

import android.app.Application
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.masa.aryan.base.BaseViewModel
import kotlinx.coroutines.launch

class ReciptPrintSettingViewModel(application: Application):BaseViewModel(application) {

 var final: MutableLiveData<String> = MutableLiveData()

 suspend fun finalAmount(){
  viewModelScope.launch {
    settingsRepository.getValue("amount")
  }

  fun getValueAmountPrint(){
   if(observableAmount.get().toString().isNotEmpty())
    return


  }
  final.postValue(finalAmount().toString())

 }




}