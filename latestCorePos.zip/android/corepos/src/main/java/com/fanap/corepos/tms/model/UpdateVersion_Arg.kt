package com.fanap.corepos.tms.model

data class UpdateVersion_Arg(

    val VersionNo: String,
    val SerialNo: String,
    val TerminalType: Int,
    val UpdateType: Int

)
