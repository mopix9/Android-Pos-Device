package com.fanap.corepos.iso.model

enum class IsoFieldLengthType {
    LL, LLL, CONST
}