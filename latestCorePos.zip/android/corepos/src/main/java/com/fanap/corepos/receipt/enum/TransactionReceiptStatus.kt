package com.fanap.corepos.receipt.enum

enum class TransactionReceiptStatus {
    Success, Fail, UnReceivedResponse,Merchant
}