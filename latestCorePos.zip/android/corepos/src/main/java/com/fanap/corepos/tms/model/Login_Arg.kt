package com.fanap.corepos.tms.model

data class Login_Arg (
    val LoginPassword: String,
    val LoginUserName: String,
    val TerminalType: Int
        )

