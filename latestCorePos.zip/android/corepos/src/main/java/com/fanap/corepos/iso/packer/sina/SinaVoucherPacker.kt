package com.fanap.corepos.iso.packer.sina

import android.util.Log
import com.fanap.corepos.device.DeviceSDKManager
import com.fanap.corepos.di.DependencyManager
import com.fanap.corepos.iso.model.SinaIsoField
import com.fanap.corepos.iso.packer.base.Packer
import com.fanap.corepos.iso.packer.sina.schema.SinaPurchasePackSchema
import com.fanap.corepos.utils.IsoUtil
import java.lang.Exception
import java.nio.charset.StandardCharsets
import java.util.*

class SinaVoucherPacker : Packer() {

    override fun pack(): ByteArray? {
        return try {
             val fields: TreeMap<Int, String?> = message
            val tempByteList = mutableListOf<Byte>()

            tempByteList.addAll(fields[0]!!.toByteArray(StandardCharsets.US_ASCII).asList()) // Mti
            tempByteList.addAll(IsoUtil.hexStringToByteArray(IsoUtil.binaryToHex(IsoUtil.createBitmap(fields.keys))).asList()) // Bitmap

            for ((key, value) in fields) { // Loop and append fields
                if (key > 1) {
                    val fieldSchema: SinaIsoField = SinaPurchasePackSchema.getIsoFieldInfo(key)
                    when (key) {
                        3, 4, 8, 11, 12, 13, 14, 41, 42 ->
                            tempByteList.addAll(
                                IsoUtil.padleft(value, fieldSchema.length, '0')
                                    .toByteArray(StandardCharsets.US_ASCII)
                                    .asList()
                            )
                        2, 34, 35 -> {
                            val length_34: String = IsoUtil.padleft(value?.length.toString(), 2, '0')
                            tempByteList.addAll(
                                (length_34 + value)
                                    .toByteArray(StandardCharsets.US_ASCII)
                                    .asList()
                            )
                        }
                        48 -> {
                            val temp = "04EOC$value"
                            val length_48: String = IsoUtil.padleft(temp.length.toString(), 3, '0')
                            tempByteList.addAll(
                                (length_48 + temp)
                                    .toByteArray(StandardCharsets.US_ASCII)
                                    .asList()
                            )
                        }
                        52 -> {
                            tempByteList.addAll(IsoUtil.hexStringToByteArray(value).asList())
                        }
                    }
                }
            }


            /*val mac: ByteArray = IsoUtil.DoMac(
                tempByteList.toByteArray()
                , IsoUtil.hexStringToByteArray(DependencyManager.macKey)
            )*/

            val mac: ByteArray = DeviceSDKManager.getHSMInterface(null)?.calcMac(tempByteList.toByteArray())!!

            tempByteList.addAll(mac.asList())

            val result = mutableListOf<Byte>()
            result.addAll(
                IsoUtil.padleft(tempByteList.size.toString(), 4, '0')
                    .toByteArray(StandardCharsets.US_ASCII)
                    .asList()
            )

            result.addAll(tempByteList)

            result.toByteArray()

//            mainMessage.append(tempMessage.length)
//            mainMessage.append(tempMessage.toString())
//            mainMessage.toString().toByteArray(StandardCharsets.US_ASCII)
        } catch (e: Exception) {
            Log.d("resulttt", e.message?:"")
            null
        }
    }
}