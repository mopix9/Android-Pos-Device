package com.fanap.corepos.iso.unpacker.dotin

import android.util.ArrayMap
import com.fanap.corepos.iso.unpacker.base.UnPacker
import com.fanap.corepos.iso.utils.IsoFields
import java.util.HashMap

class DotinLogonUnPacker : UnPacker() {

    override fun unpack(): HashMap<IsoFields, String> {
        TODO("Not yet implemented")
    }

}