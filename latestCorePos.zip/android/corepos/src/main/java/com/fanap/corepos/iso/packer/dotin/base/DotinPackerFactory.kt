package com.fanap.corepos.iso.packer.dotin.base

import android.util.ArrayMap
import com.fanap.corepos.iso.packer.base.IPackerFactory
import com.fanap.corepos.iso.packer.base.Packer
import com.fanap.corepos.iso.utils.IsoFields
import java.util.*

class DotinPackerFactory : IPackerFactory {

    override fun getPacker(msg: HashMap<IsoFields, String>): Packer {
        TODO("Not yet implemented")
    }
}