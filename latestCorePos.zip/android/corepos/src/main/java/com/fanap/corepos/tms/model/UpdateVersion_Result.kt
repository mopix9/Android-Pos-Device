package com.fanap.corepos.tms.model

data class UpdateVersion_Result(

     val responseDesc: String,
     val responseCode: Int

)
