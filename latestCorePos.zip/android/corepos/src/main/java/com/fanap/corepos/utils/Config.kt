package com.fanap.corepos.utils

class Config {
}