package com.fanap.corepos.device.install.justtide;

import com.fanap.corepos.device.install.FileUtil;
import com.fanap.corepos.device.install.InstallInterface;
import com.pos.device.sys.SystemManager;

public class JusttideInstallApp implements InstallInterface {

    public boolean installApk(String apkAddress) {
        return false;
    }

}
