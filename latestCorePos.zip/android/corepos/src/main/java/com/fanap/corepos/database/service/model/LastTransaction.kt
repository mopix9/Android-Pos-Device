package com.fanap.corepos.database.service.model

class LastTransaction(
    var id: Long,
    var status: String,
    var rrn: String,
    var responseCode: String,
    var dateTime: String
)
