package com.fanap.corepos.iso.model

enum class IsoFieldApplication {
    MANDATORY, CONDITIONAL, OPTIONAL
}