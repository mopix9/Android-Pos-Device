package com.fanap.corepos.tms.utils

object TmsConstants {

    var TOKEN = ""
    var LOGIN_PASSWORD = "Pos!@#123"
    var LOGIN_USERNAME = "androidpos"
    var TERMINAL_TYPE = 3
    var ENCRYPTED_USERNAME = ""
    var UPDATE_TYPE = 1
}