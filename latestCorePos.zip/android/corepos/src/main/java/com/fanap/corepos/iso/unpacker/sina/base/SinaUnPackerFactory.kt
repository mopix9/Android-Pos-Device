package com.fanap.corepos.iso.unpacker.sina.base

import com.fanap.corepos.iso.unpacker.base.IUnPackerFactory
import com.fanap.corepos.iso.unpacker.base.UnPacker
import com.fanap.corepos.iso.unpacker.sina.*
import com.fanap.corepos.iso.unpacker.sina.SinaBalanceUnPacker
import com.fanap.corepos.iso.unpacker.sina.SinaLogonUnPacker
import com.fanap.corepos.iso.unpacker.sina.SinaVoucherUnPacker
import com.fanap.corepos.utils.IsoUtil
import java.lang.IllegalArgumentException

class SinaUnPackerFactory : IUnPackerFactory {

    override fun getUnPacker(msg: ByteArray): UnPacker {

        val message = IsoUtil.bytesToHex(msg).toCharArray()

        return when (getProcessCode(message)) {
            "180000" -> SinaTopupUnPacker()
            "170000" -> SinaBillUnPacker()
            "190000" -> SinaVoucherUnPacker()
            "310000" -> SinaBalanceUnPacker()
            "250000" -> SinaLogonUnPacker()
            "000000" -> {
                when (getMti(message)){
                    "0210" -> SinaBuyUnPacker()
                    "0230" -> SinaAdviseUnPacker()
                    "0410" -> SinaReverseUnPacker()
                    else -> throw IllegalArgumentException()
                }

            }
            else -> throw IllegalArgumentException("Undefined MTI!")
        }
    }

    private fun getProcessCode(msg : CharArray)  =
        IsoUtil.hexToAscii(msg.sliceArray(32 until 32+12).concatToString())

    private fun getMti(msg : CharArray)  =
        IsoUtil.hexToAscii(msg.sliceArray(8 until 8+8).concatToString())

}