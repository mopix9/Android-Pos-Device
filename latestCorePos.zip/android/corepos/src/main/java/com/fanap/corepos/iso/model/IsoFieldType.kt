package com.fanap.corepos.iso.model

enum class DotinFieldTypes{ HEX, BCD, UNDEFINED }
enum class SinaFieldTypes{ N, B, AN, ANS }
enum class SayanFieldTypes{ N, B, AN, ANS, Z }
enum class SayanDataTypes{ HEX, ASCII}
enum class AryanDataTypes{ HEX, ASCII}
enum class AryanFieldTypes{ N, B, AN, ANS, Z}


