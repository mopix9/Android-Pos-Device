package com.fanap.corepos.device.install.xcheng;

import com.fanap.corepos.device.install.InstallInterface;

public class XchengInstallApp implements InstallInterface {

    public boolean installApk(String apkAddress) {
        return false;
    }

}
