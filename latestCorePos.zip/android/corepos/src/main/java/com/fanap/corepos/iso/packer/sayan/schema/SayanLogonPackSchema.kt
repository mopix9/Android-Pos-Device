package com.fanap.corepos.iso.packer.sayan.schema

import com.fanap.corepos.iso.model.*
import java.lang.IllegalArgumentException


object SayanLogonPackSchema {
    /**
     * @param fieldNumber bit number of iso field in iso message
     * @return iso field specification like type,length and ...
     */
    fun getIsoFieldInfo(fieldNumber: Int): SayanIsoField {
        return when (fieldNumber) {
            3, 11, 12 -> SayanIsoField(6, SayanFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST, SayanDataTypes.HEX)
            13 -> SayanIsoField(4, SayanFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST, SayanDataTypes.HEX)
            24 -> SayanIsoField(4, SayanFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST, SayanDataTypes.HEX)
            48 -> SayanIsoField(999, SayanFieldTypes.ANS, IsoFieldApplication.MANDATORY,IsoFieldLengthType.LLL, SayanDataTypes.ASCII)
            else -> throw IllegalArgumentException("Invalid iso field!")
        }
    }
}