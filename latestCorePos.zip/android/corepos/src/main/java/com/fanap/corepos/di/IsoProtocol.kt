package com.fanap.corepos.di

enum class IsoProtocol {
    DOTIN,SINA,SAYAN,ARYAN,FANAVA
}