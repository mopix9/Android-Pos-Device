package com.fanap.corepos.iso.packer.sina.schema

import com.fanap.corepos.iso.model.*
import java.lang.IllegalArgumentException


object SinaLogonPackSchema {
    /**
     * @param fieldNumber bit number of iso field in iso message
     * @return iso field specification like type,length and ...
     */
    fun getIsoFieldInfo(fieldNumber: Int): SinaIsoField {
        return when (fieldNumber) {
            3, 8, 11, 12 -> SinaIsoField(6, SinaFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST)
            13, 41 -> SinaIsoField(8, SinaFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST)
            34 -> SinaIsoField(30, SinaFieldTypes.AN, IsoFieldApplication.MANDATORY,IsoFieldLengthType.LL)
            42 -> SinaIsoField(15, SinaFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST)
            48 -> SinaIsoField(999, SinaFieldTypes.ANS, IsoFieldApplication.OPTIONAL,IsoFieldLengthType.LLL)
            else -> throw IllegalArgumentException("Invalid iso field!")
        }
    }
}