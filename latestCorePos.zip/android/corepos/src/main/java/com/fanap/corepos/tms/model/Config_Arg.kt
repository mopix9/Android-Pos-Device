package com.fanap.corepos.tms.model

data class Config_Arg (
     val LoginUserName: String,
             val TerminalType: Int,
             val SerialNo: String
)