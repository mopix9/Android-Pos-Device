package com.fanap.corepos.tms.model

data class Login_Result(
     val userToken: String,
     val encrypteUsername: String
)
