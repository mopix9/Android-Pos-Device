package com.fanap.corepos.receipt.util

enum class ReceiptProtocol {
    PASARGOD,SINA,ARYAN
}