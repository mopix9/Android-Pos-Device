package com.fanap.corepos.tms.model

data class Termianl_Arg(
     var SerialNo: String,
     val LoginUserName: String,
     val TerminalType: Int

)
