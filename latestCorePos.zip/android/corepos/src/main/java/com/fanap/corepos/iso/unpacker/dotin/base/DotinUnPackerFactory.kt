package com.fanap.corepos.iso.unpacker.dotin.base

import com.fanap.corepos.iso.unpacker.base.IUnPackerFactory
import com.fanap.corepos.iso.unpacker.base.UnPacker

class DotinUnPackerFactory : IUnPackerFactory {

    override fun getUnPacker(msg: ByteArray): UnPacker {
        TODO("Not yet implemented")
    }
}