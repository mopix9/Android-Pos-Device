package com.fanap.corepos.iso.packer.sina.base

import com.fanap.corepos.iso.packer.base.IPackerFactory
import com.fanap.corepos.iso.packer.base.Packer
import com.fanap.corepos.iso.packer.sina.*
import com.fanap.corepos.iso.utils.IsoFields
import java.lang.IllegalArgumentException
import java.util.*

class SinaPackerFactory : IPackerFactory {

    override fun getPacker(msg: HashMap<IsoFields, String>): Packer {
        return when (msg[IsoFields.ProcessCode]) {
            "180000" -> SinaTopupPacker()
            "170000" -> SinaBillPacker()
           // "190000", "180000" -> ChargePacker()
            //"170000" -> BillPacker()
            "190000" -> SinaVoucherPacker()
            "310000" -> SinaBalancePacker()
            "250000" -> SinaLogonPacker()
            "000000" -> {
                when (msg[IsoFields.Mti]!!){
                    "0200" -> SinaBuyPacker()
                    "0220" -> SinaAdvisePacker()
                    "0400" -> SinaReversePacker()
                    else -> throw IllegalArgumentException()
                }

            }
            else -> throw IllegalArgumentException("Undefined MTI!")
        }
    }
}