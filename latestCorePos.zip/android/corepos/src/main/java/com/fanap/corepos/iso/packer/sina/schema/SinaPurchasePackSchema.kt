package com.fanap.corepos.iso.packer.sina.schema

import com.fanap.corepos.iso.model.*
import java.lang.IllegalArgumentException


object SinaPurchasePackSchema {
    /**
     * @param fieldNumber bit number of iso field in iso message
     * @return iso field specification like type,length and ...
     */
    fun getIsoFieldInfo(fieldNumber: Int): SinaIsoField {
        return when (fieldNumber) {
            14 -> SinaIsoField(4, SinaFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST)
            3, 8, 11, 12 -> SinaIsoField(6, SinaFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST)
            13, 41 -> SinaIsoField(8, SinaFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST)
            52 -> SinaIsoField(8, SinaFieldTypes.B, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST)
            4 -> SinaIsoField(12, SinaFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST)
            42 -> SinaIsoField(15, SinaFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST)
            2 -> SinaIsoField(19, SinaFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.LL)
            34 -> SinaIsoField(30, SinaFieldTypes.AN, IsoFieldApplication.MANDATORY,IsoFieldLengthType.LL)
            35 -> SinaIsoField(37, SinaFieldTypes.ANS, IsoFieldApplication.MANDATORY,IsoFieldLengthType.LL)
            48 -> SinaIsoField(999, SinaFieldTypes.ANS, IsoFieldApplication.OPTIONAL,IsoFieldLengthType.LLL)
            62 -> SinaIsoField(999, SinaFieldTypes.ANS, IsoFieldApplication.OPTIONAL,IsoFieldLengthType.LLL)
            else -> throw IllegalArgumentException("Invalid iso field!")
        }
    }
}