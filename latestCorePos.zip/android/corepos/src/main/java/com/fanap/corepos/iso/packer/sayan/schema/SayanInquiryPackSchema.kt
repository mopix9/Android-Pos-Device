package com.fanap.corepos.iso.packer.sayan.schema

import com.fanap.corepos.iso.model.*
import java.lang.IllegalArgumentException


object SayanInquiryPackSchema {
    /**
     * @param fieldNumber bit number of iso field in iso message
     * @return iso field specification like type,length and ...
     */
    fun getIsoFieldInfo(fieldNumber: Int): SayanIsoField {
        return when (fieldNumber) {
            3, 11, 12 -> SayanIsoField(6, SayanFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST, SayanDataTypes.HEX)
            13 -> SayanIsoField(4, SayanFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST, SayanDataTypes.HEX)
            14 -> SayanIsoField(4, SayanFieldTypes.N, IsoFieldApplication.CONDITIONAL,IsoFieldLengthType.CONST, SayanDataTypes.HEX)
            22, 24 -> SayanIsoField(4, SayanFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST, SayanDataTypes.HEX)
            25 -> SayanIsoField(2, SayanFieldTypes.N, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST, SayanDataTypes.HEX)
            35 -> SayanIsoField(37, SayanFieldTypes.Z, IsoFieldApplication.MANDATORY,IsoFieldLengthType.LL, SayanDataTypes.HEX)
            41 -> SayanIsoField(8, SayanFieldTypes.ANS, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST, SayanDataTypes.ASCII)
            42 -> SayanIsoField(15, SayanFieldTypes.ANS, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST, SayanDataTypes.ASCII)
            48 -> SayanIsoField(999, SayanFieldTypes.ANS, IsoFieldApplication.MANDATORY,IsoFieldLengthType.LLL, SayanDataTypes.ASCII)
            52, 64 -> SayanIsoField(8, SayanFieldTypes.B, IsoFieldApplication.MANDATORY,IsoFieldLengthType.CONST, SayanDataTypes.HEX)

            else -> throw IllegalArgumentException("Invalid iso field!")
        }
    }
}