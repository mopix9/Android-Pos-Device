package com.fanap.corepos.database.common

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.fanap.corepos.database.service.model.Shift

@Dao
interface ShiftDao {
    @Query("SELECT * FROM `Shift`")
    suspend fun getAllValues(): List<Shift>?

    @Query("SELECT * FROM `Shift` where name = :name")
    suspend fun getValue(name: String): Shift?

    @Insert
    suspend fun insert(shift: Shift)

    @Query("SELECT * FROM `Shift` ORDER BY id DESC LIMIT 1")
    suspend fun getLastShift(): Shift?

    @Query("SELECT * FROM `Shift` where startDate>= :date and name =:name ORDER BY startDate DESC LIMIT 1")
    suspend fun getShiftByName(name: Int, date: String): Shift?

    @Query("SELECT count(*) FROM `Shift`")
    suspend fun getCount(): Int?

    @Query("Delete from Shift")
    suspend fun delete()

    @Update
    suspend fun update(shift: Shift)
}
