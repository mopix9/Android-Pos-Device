package com.fanap.corepos.device.hsm

import android.content.Context
import android.graphics.Bitmap
import android.view.View
import com.fanap.corepos.device.hsm.aryan.newland.NewLandHSMAryan
import com.fanap.corepos.device.hsm.dotin.amp.AmpHSMDotin
import com.fanap.corepos.device.hsm.dotin.justtide.JusttideHSMDotin
import com.fanap.corepos.device.hsm.dotin.xcheng.XchengHSMDotin
import com.fanap.corepos.device.hsm.sayan.amp.AmpHSMSayan
import com.fanap.corepos.device.hsm.sayan.justtide.JusttideHSMSayan
import com.fanap.corepos.device.hsm.sayan.xcheng.XchengHSMSayan
import com.fanap.corepos.device.hsm.sina.amp.AmpHSMSina
import com.fanap.corepos.device.hsm.sina.justtide.JusttideHSMSina
import com.fanap.corepos.device.hsm.sina.xcheng.XchengHSMSina
import com.fanap.corepos.di.DependencyManager
import com.fanap.corepos.di.IsoProtocol
import com.fanap.corepos.iso.utils.IsoFields
import com.fanap.corepos.receipt.sina.SinaTransactionReceipt
import com.fanap.corepos.receipt.util.ReceiptUtils

object HSMFactory {

    private var protocol : IsoProtocol = DependencyManager.protocol

    fun getAmpHSM(): HSMInterface{
        return when(protocol){
            IsoProtocol.SINA -> AmpHSMSina()
            IsoProtocol.DOTIN -> AmpHSMDotin()
            IsoProtocol.SAYAN -> AmpHSMSayan()
            IsoProtocol.ARYAN -> AmpHSMSayan()
            else -> AmpHSMSayan()
        }
    }

    fun getJusttideHSM(): HSMInterface{
        return when(protocol){
            IsoProtocol.SINA -> JusttideHSMSina()
            IsoProtocol.DOTIN -> JusttideHSMDotin()
            IsoProtocol.SAYAN -> JusttideHSMSayan()
            IsoProtocol.ARYAN -> JusttideHSMSayan()
            else -> JusttideHSMSayan()
        }
    }

    fun getXchengHSM(context: Context?): HSMInterface{
        return when(protocol){
            IsoProtocol.SINA -> XchengHSMSina(context)
            IsoProtocol.DOTIN -> XchengHSMDotin(context)
            IsoProtocol.SAYAN -> XchengHSMSayan(context)
            IsoProtocol.ARYAN -> XchengHSMSayan(context)
            else -> XchengHSMSayan(context)
        }
    }

    fun getNewLandHSM(context: Context?): HSMInterface{
        return when(protocol){
            IsoProtocol.SINA -> XchengHSMSina(context)
            IsoProtocol.DOTIN -> XchengHSMDotin(context)
            IsoProtocol.SAYAN -> XchengHSMSayan(context)
            IsoProtocol.ARYAN -> NewLandHSMAryan()
            else -> NewLandHSMAryan()
        }
    }

}