package com.fanap.corepos.database.service.model

enum class SettingsNames {

    TerminalNo,
    TerminalSerial,
    MerchantNo,
    MerchantName,
    Ip,
    Port,
    Tms,
    ConnectionType,
    ReceiptType,
    Xrm,
    Pos,
    Phone,
    Address,
    Bright,
    SimCardNumber,
    Apn,
    Password,
    LastTrack2,
    BrightLevel,
    BlockedCounter,
    Ibans,
    DefaultIban,
    UpdateTimer,
    SecondReceiptTime,
    SecondReceiptEnabled,
    Nii,
    SSL,
    Amount
}