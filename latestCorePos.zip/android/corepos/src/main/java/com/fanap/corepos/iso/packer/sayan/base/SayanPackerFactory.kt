package com.fanap.corepos.iso.packer.sayan.base

import com.fanap.corepos.iso.packer.base.IPackerFactory
import com.fanap.corepos.iso.packer.base.Packer
import com.fanap.corepos.iso.packer.sayan.*
import com.fanap.corepos.iso.utils.IsoFields
import java.lang.IllegalArgumentException
import java.util.*

class SayanPackerFactory : IPackerFactory {

    override fun getPacker(msg: HashMap<IsoFields, String>): Packer {
        return when (msg[IsoFields.ProcessCode]) {
            "220000" -> SayanTopupPacker()
            "170000" -> SayanBillPacker()
            "180000" -> SayanVoucherPacker()
            "310000" -> SayanBalancePacker()
            "920000" -> SayanLogonPacker()
            "930000" -> SayanGetTerminalPacker()
            "000000" -> {
                when (msg[IsoFields.Mti]!!){
                    "0200" -> SayanBuyPacker()
                    "0220" -> SayanAdvisePacker()
                    "0420" -> SayanReversePacker()
                    else -> throw IllegalArgumentException()
                }

            }
            else -> throw IllegalArgumentException("Undefined MTI!")
        }
    }
}