package com.fanap.corepos.device.hsm.sayan.amp.other;


/**
 * Created by Symbol Tabios on 25/09/2017.
 */

public interface PinpadListener {
    void callback(PinInfo info);
}
