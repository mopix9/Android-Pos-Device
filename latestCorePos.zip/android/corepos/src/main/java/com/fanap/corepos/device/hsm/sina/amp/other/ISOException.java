package com.fanap.corepos.device.hsm.sina.amp.other;

/**
 * Created by Symbol Tabios on 25/09/2017.
 */

public class ISOException extends Exception {

    public ISOException(String msg){
        System.out.println(msg);
    }
}
