package com.fanap.corepos.tms.model

enum class ConfigNames {

    CurrentDateTime,
    CurrentPersianDateTime,
    CurrentTimestamp

}