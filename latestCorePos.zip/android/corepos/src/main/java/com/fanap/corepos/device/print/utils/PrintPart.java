package com.fanap.corepos.device.print.utils;

public enum PrintPart {
    Header,Body,Footer,All
}
