package com.fanap.corepos.iso.unpacker.sina

import android.util.ArrayMap
import com.fanap.corepos.iso.model.SinaIsoField
import com.fanap.corepos.iso.model.IsoFieldLengthType
import com.fanap.corepos.iso.model.SinaFieldTypes
import com.fanap.corepos.iso.unpacker.base.UnPacker
import com.fanap.corepos.iso.unpacker.sina.schema.SinaLogonUnPackSchema
import com.fanap.corepos.iso.utils.IranSystemUtil
import com.fanap.corepos.iso.utils.IsoFields
import com.fanap.corepos.utils.IsoUtil
import java.util.*

class SinaLogonUnPacker : UnPacker() {

    override fun unpack(): HashMap<IsoFields, String> {

        val message: CharArray = IsoUtil.bytesToHex(message).toCharArray()
        val msg = HashMap<IsoFields, String>()

        var pointer = 32 // current location in message after adding mti and bitmap in msg

        msg[IsoFields.Mti] = IsoUtil.hexToAscii(message.sliceArray(8..15).concatToString())
        msg[IsoFields.Bitmap] = message.sliceArray(16..31).concatToString()
        val bitmap: List<Int> = IsoUtil.unpackBitmap(msg[IsoFields.Bitmap])

        for (i in bitmap.indices)
            if (bitmap[i] == 1) {
                val schema: SinaIsoField = SinaLogonUnPackSchema.getIsoFieldInfo(i + 1)
            var fieldLength: Int
            when (schema.type) {
                SinaFieldTypes.N, SinaFieldTypes.AN,SinaFieldTypes.ANS ->{

                    when(schema.lengthType){
                        IsoFieldLengthType.LL -> {
                            fieldLength = IsoUtil.hexToAscii(message.sliceArray(pointer until pointer+4).concatToString()).toInt() * 2
                            pointer += 4
                            msg[getFieldName(i+1)] = IsoUtil.hexToAscii(message.sliceArray(pointer until pointer+fieldLength).concatToString())
                            pointer += fieldLength

                        }
                        IsoFieldLengthType.LLL ->{
                            fieldLength = IsoUtil.hexToAscii(message.sliceArray(pointer until pointer+6).concatToString()).toInt() * 2
                            pointer += 6
                            msg[getFieldName(i+1)] = IsoUtil.hexToAscii(message.sliceArray(pointer until pointer+fieldLength).concatToString())
                            pointer += fieldLength
                        }
                        IsoFieldLengthType.CONST ->{
                            fieldLength = schema.length * 2
                            msg[getFieldName(i+1)] = IsoUtil.hexToAscii(message.sliceArray(pointer until pointer+fieldLength).concatToString())
                            pointer += fieldLength
                        }
                    }
                }

                SinaFieldTypes.B ->{
                    fieldLength = schema.length * 2
                    msg[getFieldName(i+1)] = message.sliceArray(pointer until pointer+fieldLength).concatToString()
                    pointer += fieldLength
                }
            }
        }

        val name = IsoUtil.hexStringToByteArray(getFieldWithTagName(msg[IsoFields.Buffer1],"MCN"))
        msg[IsoFields.MerchantName] = IranSystemUtil.toString(name,0, name.size).reversed()

        msg[IsoFields.MerchantPhone] = getFieldWithTagName(msg[IsoFields.Buffer1],"MPN")

        val address = IsoUtil.hexStringToByteArray(getFieldWithTagName(msg[IsoFields.Buffer1],"ADD"))
        msg[IsoFields.Address] = IranSystemUtil.toString(address,0, name.size).reversed()

//        val mac = msg[IsoFields.Buffer2]?.substringAfter("MCK")?.take(32) ?: ""
//        val pin = msg[IsoFields.Buffer2]?.substringAfter("PNK")?.take(32) ?: ""
//        val data = msg[IsoFields.Buffer2]?.substringAfter("DTK")?.take(32)?: ""

        msg[IsoFields.MacKey] = getFieldWithTagName(msg[IsoFields.Buffer2],"MCK")
        msg[IsoFields.PinKey] = getFieldWithTagName(msg[IsoFields.Buffer2],"PNK")
        msg[IsoFields.DataKey] = getFieldWithTagName(msg[IsoFields.Buffer2],"DTK")

        return msg
        //30ADD9f9b96ff90f3f9ffeeaa91f8a4a5fd20MCN9fea91a4fdff90f5fea408MPN3580418426SH0IR470190000000329344627005
    }

    private fun getFieldName(field : Int) : IsoFields{
        return when(field){
            3 -> IsoFields.ProcessCode
            11 -> IsoFields.Stan
            12 -> IsoFields.TransactionTime
            13 -> IsoFields.TransactionDate
            34 -> IsoFields.Serial
            39 -> IsoFields.Response
            41 -> IsoFields.Terminal
            42 -> IsoFields.Merchant
            48 -> IsoFields.Buffer1
            63 -> IsoFields.Buffer2
            64 -> IsoFields.Mac
            else -> throw IllegalArgumentException()
        }
    }
}