package com.fanap.corepos.device.mag_card;

import androidx.lifecycle.LiveData;

public interface MagCardInterface {
    public void read();
    public LiveData<String> getCardTrack2LiveData();
     void closeCardReader();
}
