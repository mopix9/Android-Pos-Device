package com.fanap.corepos.tms.model

data class Update_Arg(

     val VersionNo: String,
     val SerialNo: String,
     val LoginUserName: String,
     val UpdateType: Int,
     val TerminalType: Int

)
