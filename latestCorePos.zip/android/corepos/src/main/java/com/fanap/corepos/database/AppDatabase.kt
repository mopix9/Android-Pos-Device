package com.fanap.corepos.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.fanap.corepos.database.aryan.AryanTransactionDao
import com.fanap.corepos.database.dotin.DotinTransactionDao
import com.fanap.corepos.database.service.model.*
import com.fanap.corepos.database.common.*
import com.fanap.corepos.database.sina.SinaTransactionDao
import com.fanap.corepos.device.DeviceSDKManager
import com.fanap.corepos.di.DependencyManager
import com.fanap.corepos.di.IsoProtocol
import kotlinx.coroutines.*
import kotlin.coroutines.CoroutineContext

@Database(
    entities = [Transaction::class, PosLog::class, Settings::class, Shift::class],
    version = 3
)
abstract class AppDatabase : RoomDatabase(), CoroutineScope {

    private var job: Job = Job()

    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Main + job

    abstract fun sinaTransactionDao(): SinaTransactionDao
    abstract fun dotinTransactionDao(): DotinTransactionDao
    abstract fun aryanTransactionDao(): AryanTransactionDao


    abstract fun settingsDao(): SettingsDao

    abstract fun shiftDao(): ShiftDao

    abstract fun posLogDao(): PosLogDao

    companion object {
        var INSTANCE: AppDatabase? = null
        fun getDatabase(context: Context): AppDatabase? {
            if (INSTANCE == null) {
                synchronized(AppDatabase::class.java) {
                    if (INSTANCE == null) {
                        INSTANCE = Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "db").addCallback( object : Callback() {
                            override fun onCreate(db: SupportSQLiteDatabase) {
                                super.onCreate(db)
                                initDatabase()
                            }
                        }).build()
                    }
                }
            }
            return INSTANCE
        }


        private fun initDatabase() {
            INSTANCE?.launch {
                INSTANCE!!.settingsDao().insert(
                    Settings(SettingsNames.TerminalSerial.name, DeviceSDKManager.getSerialInterface()?.serial ?: "0000000000"))

                when(DependencyManager.protocol){
                    IsoProtocol.ARYAN -> {
                        INSTANCE!!.settingsDao().insert(Settings(SettingsNames.Ip.name, "87.107.134.151"))
                        INSTANCE!!.settingsDao().insert(Settings(SettingsNames.Port.name, "5050"))
                        INSTANCE!!.settingsDao().insert(Settings(SettingsNames.Nii.name, "0768"))
                    }

                    IsoProtocol.FANAVA -> {
                        INSTANCE!!.settingsDao().insert(Settings(SettingsNames.Ip.name, "78.157.33.208"))
                        INSTANCE!!.settingsDao().insert(Settings(SettingsNames.Port.name, "4142"))
                        INSTANCE!!.settingsDao().insert(Settings(SettingsNames.Nii.name, "09"))
                    }
                }

                delay(1500)
            }

        }

    }
}
