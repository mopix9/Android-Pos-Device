package com.fanap.corepos.receipt.enum

enum class TransactionType {
    Buy, Bill, Balance, Topup, Voucher,
    Settings,Total,DetailList
}