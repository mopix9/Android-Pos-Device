package com.fanap.corepos.device.hsm.sina.xcheng;

public class PinpadInterfaceVersion {
	
    public static final int PINPAD_INTERFACE_VERSION = 1;
    
    public static final int PINPAD_INTERFACE_DUKPT = 2;
    
}
