package com.fanap.corepos.device.serial;

public interface SerialInterface {

    public String getSerial();
}
