package com.fanap.corepos.receipt.enum

enum class PrintPart {
    Header,Body,Footer,All
}