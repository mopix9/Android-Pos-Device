package com.fanap.corepos.iso.packer.sayan

import com.fanap.corepos.device.DeviceSDKManager
import com.fanap.corepos.di.DependencyManager
import com.fanap.corepos.iso.model.SinaIsoField
import com.fanap.corepos.iso.packer.base.Packer
import com.fanap.corepos.iso.packer.sina.schema.AdviseReversePackSchema
import com.fanap.corepos.utils.IsoUtil
import java.lang.Exception
import java.nio.charset.StandardCharsets
import java.util.*

class SayanAdvisePacker  : Packer() {

    override fun pack(): ByteArray? {
        return try {
            val fields: TreeMap<Int, String?> = message
            val tempByteList = mutableListOf<Byte>()

            tempByteList.addAll(fields[0]!!.toByteArray(StandardCharsets.US_ASCII).asList()) // Mti
            tempByteList.addAll(IsoUtil.hexStringToByteArray(IsoUtil.binaryToHex(IsoUtil.createBitmap(fields.keys))).asList()) // Bitmap

            for ((key, value) in fields) { // Loop and append fields
                if (key > 1) {
                    val fieldSchema: SinaIsoField = AdviseReversePackSchema.getIsoFieldInfo(key)
                    when (key) {
                        3, 4, 8, 11, 12, 13, 41, 42 ->
                            tempByteList.addAll(
                                IsoUtil.padleft(value, fieldSchema.length, '0')
                                    .toByteArray(StandardCharsets.US_ASCII)
                                    .asList()
                            )
                        2, 34 -> {
                            val length_34: String = IsoUtil.padleft(value?.length.toString(), 2, '0')
                            tempByteList.addAll(
                                (length_34 + value)
                                    .toByteArray(StandardCharsets.US_ASCII)
                                    .asList()
                            )
                        }
                        48 -> {
                            val data  = value!!.split("~")

                            val otd = data[0].length.toString() + "OTD" + data[0]
                            val ots =  "06OTS" + IsoUtil.padleft(data[1],6,'0')
                            val otr = data[2].length.toString() + "OTR" + data[2]

                            val finaData = otd + ots + otr
                            val finalLength = IsoUtil.padleft(finaData.length.toString(), 3, '0')

                            tempByteList.addAll(
                                (finalLength + finaData)
                                    .toByteArray(StandardCharsets.US_ASCII)
                                    .asList()
                            )
                        }

                    }
                }
            }

            val mac: ByteArray = DeviceSDKManager.getHSMInterface(null)?.calcMac(tempByteList.toByteArray())!!

            tempByteList.addAll(mac.asList())

            val result = mutableListOf<Byte>()
            result.addAll(
                IsoUtil.padleft(tempByteList.size.toString(), 4, '0')
                    .toByteArray(StandardCharsets.US_ASCII)
                    .asList()
            )

            result.addAll(tempByteList)
            result.toByteArray()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}