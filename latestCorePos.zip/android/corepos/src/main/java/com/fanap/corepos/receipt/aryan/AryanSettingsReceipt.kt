package com.fanap.corepos.receipt.aryan

import android.content.Context
import android.graphics.Bitmap
import android.view.LayoutInflater
import androidx.databinding.DataBindingUtil
import com.fanap.corepos.R
import com.fanap.corepos.databinding.AryanSettingsReceiptBinding
import com.fanap.corepos.iso.utils.IsoFields
import com.fanap.corepos.receipt.Receipt

class AryanSettingsReceipt(val context: Context,val data: HashMap<IsoFields, String>) : Receipt() {

    private lateinit var binding: AryanSettingsReceiptBinding

    override fun generate(): Bitmap {
        binding = DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.aryan_settings_receipt, null, false)
        val view = binding.getRoot()

        binding.txtMerchantName.text = data[IsoFields.MerchantName]  ?: ""
        binding.txtMerchantTerminal.text = "${data[IsoFields.Merchant]?.trim()}/${data[IsoFields.Terminal]}"
        binding.txtIp.text = data[IsoFields.Buffer1]  ?: ""
        binding.txtPort.text = data[IsoFields.Buffer2]  ?: ""
        binding.txtNii.text = data[IsoFields.NiiCode]  ?: ""

        return view.convertViewToBitmap()
    }
}