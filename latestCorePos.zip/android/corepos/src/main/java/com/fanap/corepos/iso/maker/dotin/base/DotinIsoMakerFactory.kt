package com.fanap.corepos.iso.maker.dotin.base

import android.util.ArrayMap
import com.fanap.corepos.iso.maker.base.IMakerFactory
import com.fanap.corepos.iso.maker.base.Maker
import com.fanap.corepos.iso.utils.IsoFields

class DotinIsoMakerFactory : IMakerFactory {

    override fun getIsoMaker(msg: HashMap<IsoFields, String>): Maker {
        TODO("Not yet implemented")
    }
}