package com.fanap.corepos.device.beep;

public interface BeepInterface {
    /*
     * param beepType : Utils.BEEP_TYPE_SUCCESS
     */
    public void beep(BeepType beepType);
}
